export type ConnectionStatus =
  | "idle"
  | "connecting"
  | "connected"
  | "disconnected"
  | "error";

export interface MetricPoint {
  t: number;
  cpu: number;
  frameMs: number;
  jank: number;
  heapMb: number;
  externalMb: number;
}

export interface GcEvent {
  id: string;
  t: number;
  reason: string;
  isolate?: string;
}

export interface NetworkRequest {
  id: string;
  t: number;
  method: string;
  uri: string;
  latencyMs: number;
  requestBytes: number;
  responseBytes: number;
  status?: number;
}

export interface ExtensionInfo {
  available: boolean;
  methods: string[];
  message?: string;
}

export interface BridgeStatusMessage {
  type: "status";
  status: ConnectionStatus;
  message?: string;
  mode?: "live" | "mock";
  isolateName?: string;
}

export interface BridgeMetricsMessage {
  type: "metrics";
  point: MetricPoint;
}

export interface BridgeGcMessage {
  type: "gc";
  event: GcEvent;
}

export interface BridgeNetworkMessage {
  type: "network";
  available: boolean;
  request?: NetworkRequest;
  message?: string;
}

export interface BridgeExtensionMessage {
  type: "extension";
  info: ExtensionInfo;
}

export interface BridgeErrorMessage {
  type: "error";
  message: string;
}

export type BridgeServerMessage =
  | BridgeStatusMessage
  | BridgeMetricsMessage
  | BridgeGcMessage
  | BridgeNetworkMessage
  | BridgeExtensionMessage
  | BridgeErrorMessage;

export type BridgeClientMessage =
  | { type: "connect"; url: string }
  | { type: "disconnect" }
  | { type: "mock" }
  | { type: "refreshExtensions" }
  | { type: "stress"; action: string; params?: Record<string, unknown> };
