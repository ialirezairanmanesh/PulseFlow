"use client";

import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Activity, Link2, Unplug, Radio } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { MetricsCharts } from "@/components/metrics-charts";
import { StressControls } from "@/components/stress-controls";
import { PulseBridgeClient } from "@/lib/bridge-client";
import type {
  BridgeServerMessage,
  ConnectionStatus,
  ExtensionInfo,
  GcEvent,
  MetricPoint,
  NetworkRequest,
} from "@/lib/types";

const MAX_POINTS = 60;
const MAX_GC = 40;
const MAX_NET = 40;

function statusVariant(status: ConnectionStatus, mode?: "live" | "mock") {
  if (status === "error") return "error" as const;
  if (status === "connected" && mode === "mock") return "mock" as const;
  if (status === "connected") return "live" as const;
  return "idle" as const;
}

export function Dashboard() {
  const [url, setUrl] = useState("ws://127.0.0.1:8181/ws");
  const [bridgeReady, setBridgeReady] = useState(false);
  const [status, setStatus] = useState<ConnectionStatus>("idle");
  const [mode, setMode] = useState<"live" | "mock" | undefined>();
  const [statusMessage, setStatusMessage] = useState("Starting bridge client…");
  const [isolateName, setIsolateName] = useState<string>();
  const [error, setError] = useState<string>();
  const [points, setPoints] = useState<MetricPoint[]>([]);
  const [gcEvents, setGcEvents] = useState<GcEvent[]>([]);
  const [network, setNetwork] = useState<NetworkRequest[]>([]);
  const [networkAvailable, setNetworkAvailable] = useState<boolean | null>(null);
  const [networkMessage, setNetworkMessage] = useState<string>();
  const [extension, setExtension] = useState<ExtensionInfo | null>(null);
  const clientRef = useRef<PulseBridgeClient | null>(null);

  const connected = status === "connected";
  const showHero = !connected;

  useEffect(() => {
    const client = new PulseBridgeClient({
      onOpen: () => {
        setBridgeReady(true);
        setStatusMessage("Bridge ready — connect a VM Service URL or start demo mode");
      },
      onClose: () => {
        setBridgeReady(false);
      },
      onError: () => {
        setError("Could not reach the PulseFlow bridge on port 3847");
      },
      onMessage: (msg: BridgeServerMessage) => {
        switch (msg.type) {
          case "status":
            setStatus(msg.status);
            setStatusMessage(msg.message ?? msg.status);
            if (msg.mode) setMode(msg.mode);
            if (msg.isolateName) setIsolateName(msg.isolateName);
            if (msg.status === "error") setError(msg.message);
            else if (msg.status === "connected" || msg.status === "idle") setError(undefined);
            if (msg.status === "disconnected" || msg.status === "idle") {
              // keep last chart samples for context
            }
            break;
          case "metrics":
            setPoints((prev) => [...prev, msg.point].slice(-MAX_POINTS));
            break;
          case "gc":
            setGcEvents((prev) => [...prev, msg.event].slice(-MAX_GC));
            break;
          case "network":
            setNetworkAvailable(msg.available);
            if (msg.message) setNetworkMessage(msg.message);
            if (msg.request) {
              setNetwork((prev) => [...prev, msg.request!].slice(-MAX_NET));
            }
            break;
          case "extension":
            setExtension(msg.info);
            break;
          case "error":
            setError(msg.message);
            break;
        }
      },
    });
    clientRef.current = client;
    client.connect();
    return () => client.dispose();
  }, []);

  const send = (fn: () => void) => {
    try {
      fn();
      setError(undefined);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Bridge command failed");
    }
  };

  const handleConnect = () =>
    send(() => {
      setPoints([]);
      setGcEvents([]);
      setNetwork([]);
      setNetworkAvailable(null);
      setExtension(null);
      clientRef.current?.send({ type: "connect", url: url.trim() });
    });

  const handleDisconnect = () =>
    send(() => clientRef.current?.send({ type: "disconnect" }));

  const handleMock = () =>
    send(() => {
      setPoints([]);
      setGcEvents([]);
      setNetwork([]);
      setNetworkAvailable(null);
      clientRef.current?.send({ type: "mock" });
    });

  const handleStress = (action: string, params?: Record<string, unknown>) =>
    send(() => clientRef.current?.send({ type: "stress", action, params }));

  return (
    <div className="relative min-h-screen overflow-hidden">
      <div className="pointer-events-none absolute inset-0 atmosphere" aria-hidden />
      <div className="pointer-events-none absolute inset-0 grain" aria-hidden />

      <header className="relative z-10 mx-auto flex max-w-6xl items-center justify-between px-5 py-5 md:px-8">
        <div className="flex items-center gap-3">
          <motion.span
            className="pulse-orb"
            animate={{ scale: connected ? [1, 1.08, 1] : 1, opacity: connected ? [0.85, 1, 0.85] : 0.7 }}
            transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
          />
          <span className="font-[family-name:var(--font-display)] text-xl tracking-tight text-[var(--ink)] md:text-2xl">
            PulseFlow
          </span>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant={statusVariant(status, mode)}>
            {mode === "mock" && connected ? "demo mode" : status}
          </Badge>
          {!bridgeReady && <Badge variant="idle">bridge…</Badge>}
        </div>
      </header>

      <main className="relative z-10 mx-auto max-w-6xl px-5 pb-16 md:px-8">
        <AnimatePresence mode="wait">
          {showHero ? (
            <motion.section
              key="hero"
              initial={{ opacity: 1, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.35, ease: "easeOut" }}
              className="grid min-h-[72vh] items-center gap-10 lg:grid-cols-[1.1fr_0.9fr]"
            >
              <div>
                <h1 className="font-[family-name:var(--font-display)] text-5xl leading-[0.95] tracking-tight text-[var(--ink)] sm:text-6xl md:text-7xl">
                  PulseFlow
                </h1>
                <p className="mt-5 max-w-md text-lg text-[var(--ink-muted)]">
                  A lightweight Flutter performance dashboard — CPU, jank, memory, and network
                  from the Dart VM Service, without DevTools clutter.
                </p>
                <div className="mt-8 flex flex-wrap gap-3">
                  <Button size="lg" onClick={handleConnect} disabled={!bridgeReady || status === "connecting"}>
                    <Link2 className="h-4 w-4" />
                    Connect live
                  </Button>
                  <Button size="lg" variant="secondary" onClick={handleMock} disabled={!bridgeReady}>
                    <Radio className="h-4 w-4" />
                    Try demo mode
                  </Button>
                </div>
              </div>

              <motion.div
                className="connect-panel"
                initial={{ opacity: 1, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4 }}
              >
                <div className="mb-4 flex items-center gap-2 text-[var(--accent)]">
                  <Activity className="h-4 w-4" />
                  <span className="text-xs font-semibold uppercase tracking-[0.16em]">
                    Connection manager
                  </span>
                </div>
                <Label htmlFor="vm-url">VM Service WebSocket URL</Label>
                <Input
                  id="vm-url"
                  className="mt-2 font-mono text-[13px]"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  placeholder="ws://127.0.0.1:xxxx/ws"
                  disabled={status === "connecting"}
                />
                <p className="mt-2 text-sm text-[var(--ink-faint)]">
                  From your Flutter run output: look for a line like{" "}
                  <code className="text-[var(--accent)]">http://127.0.0.1:xxxx</code> and use{" "}
                  <code className="text-[var(--accent)]">ws://127.0.0.1:xxxx/ws</code>.
                </p>
                <div className="mt-5 flex flex-wrap gap-2">
                  <Button onClick={handleConnect} disabled={!bridgeReady || status === "connecting"}>
                    {status === "connecting" ? "Connecting…" : "Connect"}
                  </Button>
                  <Button variant="ghost" onClick={handleMock} disabled={!bridgeReady}>
                    Demo without Flutter
                  </Button>
                </div>
                <div className="mt-4 min-h-[3rem] text-sm">
                  {error ? (
                    <p className="rounded-md border border-rose-400/25 bg-rose-500/10 px-3 py-2 text-rose-200">
                      {error}
                    </p>
                  ) : (
                    <p className="text-[var(--ink-muted)]">{statusMessage}</p>
                  )}
                </div>
              </motion.div>
            </motion.section>
          ) : (
            <motion.div
              key="dash"
              initial={{ opacity: 1, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35 }}
              className="space-y-5"
            >
              <section className="flex flex-col gap-4 rounded-xl border border-white/10 bg-black/20 px-4 py-4 backdrop-blur-sm md:flex-row md:items-end md:justify-between">
                <div className="min-w-0 flex-1">
                  <Label htmlFor="vm-url-live">VM Service</Label>
                  <div className="mt-2 flex flex-col gap-2 sm:flex-row">
                    <Input
                      id="vm-url-live"
                      className="font-mono text-[13px]"
                      value={url}
                      onChange={(e) => setUrl(e.target.value)}
                      disabled={connected && mode === "live"}
                    />
                    {connected ? (
                      <Button variant="danger" onClick={handleDisconnect}>
                        <Unplug className="h-4 w-4" />
                        Disconnect
                      </Button>
                    ) : (
                      <Button onClick={handleConnect}>Connect</Button>
                    )}
                  </div>
                  <p className="mt-2 text-sm text-[var(--ink-muted)]">
                    {statusMessage}
                    {isolateName ? ` · isolate ${isolateName}` : ""}
                    {mode === "mock" ? " · labeled demo metrics" : ""}
                  </p>
                  {error && (
                    <p className="mt-2 rounded-md border border-rose-400/25 bg-rose-500/10 px-3 py-2 text-sm text-rose-200">
                      {error}
                    </p>
                  )}
                </div>
                <div className="flex flex-wrap gap-3 text-sm text-[var(--ink-muted)]">
                  <Stat label="CPU" value={points.at(-1) ? `${points.at(-1)!.cpu}%` : "—"} />
                  <Stat
                    label="Frame"
                    value={points.at(-1) ? `${points.at(-1)!.frameMs.toFixed(1)} ms` : "—"}
                  />
                  <Stat
                    label="Heap"
                    value={points.at(-1) ? `${points.at(-1)!.heapMb.toFixed(1)} MB` : "—"}
                  />
                </div>
              </section>

              <MetricsCharts
                points={points}
                gcEvents={gcEvents}
                network={network}
                networkAvailable={networkAvailable}
                networkMessage={networkMessage}
                connected={connected}
              />

              <StressControls
                extension={extension}
                disabled={!connected}
                onStress={handleStress}
                onRefresh={() =>
                  send(() => clientRef.current?.send({ type: "refreshExtensions" }))
                }
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="min-w-[88px] rounded-md border border-white/8 bg-white/5 px-3 py-2">
      <div className="text-[10px] uppercase tracking-[0.14em] text-[var(--ink-faint)]">{label}</div>
      <div className="font-[family-name:var(--font-display)] text-lg text-[var(--ink)]">{value}</div>
    </div>
  );
}
