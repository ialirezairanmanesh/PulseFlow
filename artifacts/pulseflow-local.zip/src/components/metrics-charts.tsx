"use client";

import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  ReferenceLine,
} from "recharts";
import type { GcEvent, MetricPoint, NetworkRequest } from "@/lib/types";
import { formatBytes, formatMs } from "@/lib/utils";

const tooltipStyle = {
  background: "rgba(8, 18, 28, 0.92)",
  border: "1px solid rgba(255,255,255,0.1)",
  borderRadius: 8,
  fontSize: 12,
  color: "#e8f4f2",
};

function ChartShell({
  title,
  subtitle,
  empty,
  loading,
  children,
}: {
  title: string;
  subtitle: string;
  empty?: string;
  loading?: boolean;
  children: React.ReactNode;
}) {
  return (
    <section className="relative min-h-[240px] overflow-hidden rounded-xl border border-white/10 bg-black/20 px-4 py-4 backdrop-blur-sm">
      <div className="mb-3 flex items-end justify-between gap-3">
        <div>
          <h3 className="font-[family-name:var(--font-display)] text-lg tracking-tight text-[var(--ink)]">
            {title}
          </h3>
          <p className="text-sm text-[var(--ink-muted)]">{subtitle}</p>
        </div>
      </div>
      {loading ? (
        <div className="flex h-[180px] items-center justify-center text-sm text-[var(--ink-faint)]">
          Waiting for samples…
        </div>
      ) : empty ? (
        <div className="flex h-[180px] items-center justify-center text-center text-sm text-[var(--ink-faint)]">
          {empty}
        </div>
      ) : (
        <div className="h-[180px] w-full">{children}</div>
      )}
    </section>
  );
}

export function MetricsCharts({
  points,
  gcEvents,
  network,
  networkAvailable,
  networkMessage,
  connected,
}: {
  points: MetricPoint[];
  gcEvents: GcEvent[];
  network: NetworkRequest[];
  networkAvailable: boolean | null;
  networkMessage?: string;
  connected: boolean;
}) {
  const chartData = points.map((p) => ({
    ...p,
    label: new Date(p.t).toLocaleTimeString([], {
      minute: "2-digit",
      second: "2-digit",
    }),
  }));

  const latest = points[points.length - 1];
  const jankCount = points.filter((p) => p.jank).length;

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <ChartShell
        title="CPU & jank"
        subtitle={
          latest
            ? `Frame ${formatMs(latest.frameMs)} · ${jankCount} jank samples in window`
            : "Frame render pressure vs 16ms budget"
        }
        loading={connected && points.length === 0}
        empty={!connected ? "Connect to stream CPU and frame timings" : undefined}
      >
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={chartData}>
            <defs>
              <linearGradient id="cpuFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#2dd4bf" stopOpacity={0.45} />
                <stop offset="100%" stopColor="#2dd4bf" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="frameFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#38bdf8" stopOpacity={0.35} />
                <stop offset="100%" stopColor="#38bdf8" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid stroke="rgba(255,255,255,0.06)" vertical={false} />
            <XAxis dataKey="label" tick={{ fill: "#7f9aa0", fontSize: 11 }} minTickGap={28} />
            <YAxis tick={{ fill: "#7f9aa0", fontSize: 11 }} width={36} />
            <Tooltip contentStyle={tooltipStyle} />
            <ReferenceLine y={16.67} stroke="#fb7185" strokeDasharray="4 4" />
            <Area
              type="monotone"
              dataKey="cpu"
              name="CPU pressure %"
              stroke="#2dd4bf"
              fill="url(#cpuFill)"
              strokeWidth={2}
              isAnimationActive={false}
            />
            <Area
              type="monotone"
              dataKey="frameMs"
              name="Frame ms"
              stroke="#38bdf8"
              fill="url(#frameFill)"
              strokeWidth={1.5}
              isAnimationActive={false}
            />
          </AreaChart>
        </ResponsiveContainer>
      </ChartShell>

      <ChartShell
        title="Memory"
        subtitle={
          latest
            ? `Heap ${latest.heapMb.toFixed(1)} MB · ${gcEvents.length} GC events`
            : "Heap size with GC markers"
        }
        loading={connected && points.length === 0}
        empty={!connected ? "Connect to stream heap usage" : undefined}
      >
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={chartData}>
            <defs>
              <linearGradient id="heapFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#a3e635" stopOpacity={0.35} />
                <stop offset="100%" stopColor="#a3e635" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid stroke="rgba(255,255,255,0.06)" vertical={false} />
            <XAxis dataKey="label" tick={{ fill: "#7f9aa0", fontSize: 11 }} minTickGap={28} />
            <YAxis tick={{ fill: "#7f9aa0", fontSize: 11 }} width={40} />
            <Tooltip
              contentStyle={tooltipStyle}
              formatter={(value) => [`${Number(value).toFixed(2)} MB`, "Heap"]}
            />
            <Area
              type="monotone"
              dataKey="heapMb"
              name="Heap MB"
              stroke="#a3e635"
              fill="url(#heapFill)"
              strokeWidth={2}
              isAnimationActive={false}
            />
          </AreaChart>
        </ResponsiveContainer>
      </ChartShell>

      <ChartShell
        title="Network latency"
        subtitle={
          networkAvailable === false
            ? networkMessage ?? "HTTP profile unavailable on this VM"
            : network.length
              ? `Last ${network.length} requests`
              : "API latency when the VM/DDS exposes HttpProfile"
        }
        loading={connected && networkAvailable === null && network.length === 0}
        empty={
          !connected
            ? "Connect to inspect network samples"
            : networkAvailable === false
              ? networkMessage
              : network.length === 0
                ? networkMessage ?? "No HTTP samples yet — degrade gracefully when unavailable"
                : undefined
        }
      >
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={network.slice(-20)}>
            <CartesianGrid stroke="rgba(255,255,255,0.06)" vertical={false} />
            <XAxis dataKey="method" tick={{ fill: "#7f9aa0", fontSize: 11 }} />
            <YAxis tick={{ fill: "#7f9aa0", fontSize: 11 }} width={40} />
            <Tooltip
              contentStyle={tooltipStyle}
              formatter={(value, _n, item) => {
                const r = item?.payload as NetworkRequest | undefined;
                return [
                  `${Number(value).toFixed(1)} ms · ${formatBytes(r?.responseBytes ?? 0)}`,
                  r?.uri ?? "request",
                ];
              }}
            />
            <Bar dataKey="latencyMs" fill="#38bdf8" radius={[4, 4, 0, 0]} isAnimationActive={false} />
          </BarChart>
        </ResponsiveContainer>
      </ChartShell>

      <section className="relative min-h-[240px] overflow-hidden rounded-xl border border-white/10 bg-black/20 px-4 py-4 backdrop-blur-sm">
        <h3 className="font-[family-name:var(--font-display)] text-lg tracking-tight text-[var(--ink)]">
          Recent signals
        </h3>
        <p className="mb-3 text-sm text-[var(--ink-muted)]">
          GC events and payload snapshots
        </p>
        {!connected ? (
          <p className="flex h-[160px] items-center justify-center text-sm text-[var(--ink-faint)]">
            No live session
          </p>
        ) : (
          <ul className="max-h-[180px] space-y-2 overflow-auto pr-1 text-sm">
            {gcEvents.length === 0 && network.length === 0 && (
              <li className="text-[var(--ink-faint)]">Listening for GC and network events…</li>
            )}
            {[...gcEvents]
              .slice(-8)
              .reverse()
              .map((g) => (
                <li
                  key={g.id}
                  className="flex items-center justify-between gap-3 border-b border-white/5 py-1.5 text-[var(--ink-muted)]"
                >
                  <span className="text-lime-300/90">GC · {g.reason}</span>
                  <span className="text-xs text-[var(--ink-faint)]">
                    {new Date(g.t).toLocaleTimeString()}
                  </span>
                </li>
              ))}
            {[...network]
              .slice(-6)
              .reverse()
              .map((r) => (
                <li
                  key={r.id}
                  className="flex items-center justify-between gap-3 border-b border-white/5 py-1.5 text-[var(--ink-muted)]"
                >
                  <span className="truncate">
                    <span className="text-sky-300">{r.method}</span> {r.uri}
                  </span>
                  <span className="shrink-0 text-xs text-[var(--ink-faint)]">
                    {formatMs(r.latencyMs)} · {formatBytes(r.responseBytes)}
                  </span>
                </li>
              ))}
          </ul>
        )}
      </section>
    </div>
  );
}
