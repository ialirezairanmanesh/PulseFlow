// PulseFlow stress-test extension stub
// Paste into your Flutter app (e.g. lib/pulseflow_extension.dart) and call
// `registerPulseFlowExtensions()` from `main()` before `runApp`.
//
// After hot-restart, PulseFlow can invoke these RPCs over the VM Service.

import 'dart:async';
import 'dart:developer';
import 'dart:math';

/// Holds demo state your app can listen to (e.g. with a ValueNotifier).
class PulseFlowStressState {
  PulseFlowStressState._();
  static final instance = PulseFlowStressState._();

  final List<Map<String, dynamic>> invoices = [];
  final List<List<int>> retainedBuffers = [];
}

void registerPulseFlowExtensions() {
  registerExtension('ext.pulseflow.injectInvoices', (method, params) async {
    final count = int.tryParse(params['count']?.toString() ?? '') ?? 100;
    final rng = Random();
    for (var i = 0; i < count; i++) {
      PulseFlowStressState.instance.invoices.add({
        'id': 'INV-${DateTime.now().microsecondsSinceEpoch}-$i',
        'total': rng.nextDouble() * 500,
        'lines': List.generate(8, (j) => 'Item $j'),
      });
    }
    // Touch the UI if you wire invoices into a list view.
    return ServiceExtensionResponse.result('{"ok":true,"injected":$count}');
  });

  registerExtension('ext.pulseflow.spikeCpu', (method, params) async {
    final millis = int.tryParse(params['millis']?.toString() ?? '') ?? 800;
    final sw = Stopwatch()..start();
    var acc = 0.0;
    while (sw.elapsedMilliseconds < millis) {
      acc += sin(sw.elapsedMicroseconds.toDouble());
    }
    return ServiceExtensionResponse.result('{"ok":true,"acc":$acc}');
  });

  registerExtension('ext.pulseflow.allocateMemory', (method, params) async {
    final megabytes = int.tryParse(params['megabytes']?.toString() ?? '') ?? 32;
    PulseFlowStressState.instance.retainedBuffers.add(List<int>.filled(megabytes * 1024 * 1024, 1));
    return ServiceExtensionResponse.result('{"ok":true,"megabytes":$megabytes}');
  });
}

// Example main wiring:
//
// void main() {
//   registerPulseFlowExtensions();
//   runApp(const MyApp());
// }
