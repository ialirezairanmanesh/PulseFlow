/**
 * PulseFlow WebSocket bridge
 * Proxies browser clients ↔ Dart VM Service WebSocket and streams
 * simplified performance metrics for the dashboard.
 */
import { createServer } from "node:http";
import { WebSocketServer, WebSocket } from "ws";
import { randomUUID } from "node:crypto";

const BRIDGE_PORT = Number(process.env.PULSEFLOW_BRIDGE_PORT ?? 3847);
const FRAME_BUDGET_MS = 16.67;

type ClientMsg =
  | { type: "connect"; url: string }
  | { type: "disconnect" }
  | { type: "mock" }
  | { type: "refreshExtensions" }
  | { type: "stress"; action: string; params?: Record<string, unknown> };

interface Session {
  client: WebSocket;
  vm?: WebSocket;
  mode: "idle" | "live" | "mock";
  isolateId?: string;
  pending: Map<string, { resolve: (v: unknown) => void; reject: (e: Error) => void }>;
  seq: number;
  pollTimer?: ReturnType<typeof setInterval>;
  mockTimer?: ReturnType<typeof setInterval>;
  lastFrameMs: number;
  jankWindow: number[];
  extensionMethods: string[];
  httpProfileSupported: boolean | null;
}

function send(client: WebSocket, payload: unknown) {
  if (client.readyState === WebSocket.OPEN) {
    client.send(JSON.stringify(payload));
  }
}

function isValidVmUrl(url: string): boolean {
  try {
    const u = new URL(url);
    return u.protocol === "ws:" || u.protocol === "wss:";
  } catch {
    return false;
  }
}

async function rpc(session: Session, method: string, params?: Record<string, unknown>) {
  if (!session.vm || session.vm.readyState !== WebSocket.OPEN) {
    throw new Error("VM Service is not connected");
  }
  const id = String(++session.seq);
  const message = { jsonrpc: "2.0", id, method, params };
  return new Promise<unknown>((resolve, reject) => {
    const timer = setTimeout(() => {
      session.pending.delete(id);
      reject(new Error(`RPC timeout: ${method}`));
    }, 8000);
    session.pending.set(id, {
      resolve: (v) => {
        clearTimeout(timer);
        resolve(v);
      },
      reject: (e) => {
        clearTimeout(timer);
        reject(e);
      },
    });
    session.vm!.send(JSON.stringify(message));
  });
}

function clearTimers(session: Session) {
  if (session.pollTimer) clearInterval(session.pollTimer);
  if (session.mockTimer) clearInterval(session.mockTimer);
  session.pollTimer = undefined;
  session.mockTimer = undefined;
}

function disconnectVm(session: Session, reason?: string) {
  clearTimers(session);
  if (session.vm) {
    try {
      session.vm.close();
    } catch {
      /* ignore */
    }
    session.vm = undefined;
  }
  session.mode = "idle";
  session.isolateId = undefined;
  session.extensionMethods = [];
  session.httpProfileSupported = null;
  for (const [, p] of session.pending) p.reject(new Error("disconnected"));
  session.pending.clear();
  if (reason) {
    send(session.client, { type: "status", status: "disconnected", message: reason });
  }
}

function emitMockMetrics(session: Session) {
  const t = Date.now();
  const wave = Math.sin(t / 900) * 18 + Math.sin(t / 2400) * 10;
  const spike = Math.random() > 0.92 ? 20 + Math.random() * 40 : 0;
  const frameMs = Math.max(4, 10 + wave * 0.15 + spike * 0.4 + Math.random() * 3);
  const jank = frameMs > FRAME_BUDGET_MS ? 1 : 0;
  const heapMb = 42 + Math.sin(t / 5000) * 6 + Math.random() * 2 + (spike ? 8 : 0);
  const cpu = Math.min(100, Math.max(2, 12 + wave + spike + Math.random() * 4));

  send(session.client, {
    type: "metrics",
    point: {
      t,
      cpu: Number(cpu.toFixed(1)),
      frameMs: Number(frameMs.toFixed(2)),
      jank,
      heapMb: Number(heapMb.toFixed(2)),
      externalMb: Number((8 + Math.random() * 2).toFixed(2)),
    },
  });

  if (Math.random() > 0.94) {
    send(session.client, {
      type: "gc",
      event: {
        id: randomUUID(),
        t,
        reason: Math.random() > 0.5 ? "scavenge" : "mark-sweep",
        isolate: "main",
      },
    });
  }

  if (Math.random() > 0.88) {
    const latency = 40 + Math.random() * 180 + (spike ? 120 : 0);
    send(session.client, {
      type: "network",
      available: true,
      request: {
        id: randomUUID(),
        t,
        method: ["GET", "POST", "PUT"][Math.floor(Math.random() * 3)],
        uri: `/api/invoices?page=${Math.floor(Math.random() * 8)}`,
        latencyMs: Number(latency.toFixed(1)),
        requestBytes: Math.floor(120 + Math.random() * 800),
        responseBytes: Math.floor(900 + Math.random() * 24000),
        status: Math.random() > 0.95 ? 500 : 200,
      },
    });
  }
}

function startMock(session: Session) {
  disconnectVm(session);
  session.mode = "mock";
  send(session.client, {
    type: "status",
    status: "connected",
    mode: "mock",
    message: "Demo mode — synthetic metrics (no Flutter app connected)",
    isolateName: "mock-isolate",
  });
  send(session.client, {
    type: "extension",
    info: {
      available: true,
      methods: ["ext.pulseflow.injectInvoices", "ext.pulseflow.spikeCpu"],
      message: "Mock stress actions simulate load locally",
    },
  });
  send(session.client, {
    type: "network",
    available: true,
    message: "Mock network profile enabled",
  });
  session.mockTimer = setInterval(() => emitMockMetrics(session), 500);
}

async function listenStreams(session: Session) {
  for (const streamId of ["Extension", "GC", "Timeline"]) {
    try {
      await rpc(session, "streamListen", { streamId });
    } catch {
      /* stream may already be listened or unsupported */
    }
  }
}

async function resolveIsolate(session: Session): Promise<string> {
  const vm = (await rpc(session, "getVM")) as {
    result?: {
      isolates?: Array<{ id: string; name?: string; isSystemIsolate?: boolean }>;
    };
  };
  const isolates = vm.result?.isolates ?? [];
  const main =
    isolates.find((i) => !i.isSystemIsolate && /main/i.test(i.name ?? "")) ??
    isolates.find((i) => !i.isSystemIsolate) ??
    isolates[0];
  if (!main) throw new Error("No Dart isolate found on this VM Service");
  session.isolateId = main.id;
  return main.name ?? main.id;
}

async function refreshExtensions(session: Session) {
  if (!session.isolateId) return;
  try {
    const isolate = (await rpc(session, "getIsolate", {
      isolateId: session.isolateId,
    })) as { result?: { extensionRPCs?: string[] } };
    const methods = isolate.result?.extensionRPCs ?? [];
    session.extensionMethods = methods;
    const pulse = methods.filter((m) => m.startsWith("ext.pulseflow."));
    send(session.client, {
      type: "extension",
      info: {
        available: pulse.length > 0,
        methods: pulse.length > 0 ? pulse : methods.filter((m) => m.includes("flutter")).slice(0, 8),
        message:
          pulse.length > 0
            ? "PulseFlow stress extension detected"
            : "PulseFlow extension not registered — paste the stub from README into your Flutter app",
      },
    });
  } catch (err) {
    send(session.client, {
      type: "extension",
      info: {
        available: false,
        methods: [],
        message: err instanceof Error ? err.message : "Could not list extensions",
      },
    });
  }
}

async function pollMemory(session: Session): Promise<{ heapMb: number; externalMb: number }> {
  if (!session.isolateId) return { heapMb: 0, externalMb: 0 };
  try {
    const usage = (await rpc(session, "getMemoryUsage", {
      isolateId: session.isolateId,
    })) as {
      result?: {
        heapUsage?: number;
        heapCapacity?: number;
        externalUsage?: number;
      };
    };
    const heap = usage.result?.heapUsage ?? usage.result?.heapCapacity ?? 0;
    const external = usage.result?.externalUsage ?? 0;
    return {
      heapMb: heap / (1024 * 1024),
      externalMb: external / (1024 * 1024),
    };
  } catch {
    try {
      const profile = (await rpc(session, "getAllocationProfile", {
        isolateId: session.isolateId,
      })) as {
        result?: { memoryUsage?: { heapUsage?: number; externalUsage?: number } };
      };
      const heap = profile.result?.memoryUsage?.heapUsage ?? 0;
      const external = profile.result?.memoryUsage?.externalUsage ?? 0;
      return {
        heapMb: heap / (1024 * 1024),
        externalMb: external / (1024 * 1024),
      };
    } catch {
      return { heapMb: 0, externalMb: 0 };
    }
  }
}

async function pollHttpProfile(session: Session) {
  if (!session.isolateId || session.httpProfileSupported === false) return;
  try {
    const res = (await rpc(session, "getHttpProfile", {
      isolateId: session.isolateId,
    })) as {
      result?: {
        requests?: Array<{
          id?: number | string;
          method?: string;
          uri?: string;
          startTime?: number;
          endTime?: number;
          requestBodyBytes?: number;
          responseBodyBytes?: number;
          response?: { statusCode?: number };
        }>;
      };
    };
    session.httpProfileSupported = true;
    const requests = res.result?.requests ?? [];
    // Emit only the newest few to avoid floods
    for (const r of requests.slice(-3)) {
      const start = r.startTime ?? 0;
      const end = r.endTime ?? start;
      const latencyMs = Math.max(0, (end - start) / 1000);
      send(session.client, {
        type: "network",
        available: true,
        request: {
          id: String(r.id ?? randomUUID()),
          t: Date.now(),
          method: r.method ?? "GET",
          uri: r.uri ?? "/",
          latencyMs: Number(latencyMs.toFixed(1)),
          requestBytes: r.requestBodyBytes ?? 0,
          responseBytes: r.responseBodyBytes ?? 0,
          status: r.response?.statusCode,
        },
      });
    }
    if (requests.length === 0) {
      send(session.client, {
        type: "network",
        available: true,
        message: "HTTP profile available — waiting for requests",
      });
    }
  } catch {
    if (session.httpProfileSupported === null) {
      session.httpProfileSupported = false;
      send(session.client, {
        type: "network",
        available: false,
        message:
          "HTTP profile not exposed by this VM/DDS — network panel will stay empty until available",
      });
    }
  }
}

function handleVmEvent(session: Session, event: Record<string, unknown>) {
  const kind = String(event.kind ?? "");
  const t = Date.now();

  if (kind === "GC" || kind === "GarbageCollection") {
    send(session.client, {
      type: "gc",
      event: {
        id: randomUUID(),
        t,
        reason: String(event.reason ?? event.type ?? "gc"),
        isolate: session.isolateId,
      },
    });
    return;
  }

  if (kind === "Extension") {
    const extensionKind = String(event.extensionKind ?? "");
    const data = (event.extensionData ?? {}) as Record<string, unknown>;
    if (extensionKind === "Flutter.Frame") {
      // elapsed is microseconds in Flutter frame events
      const elapsedUs = Number(data.elapsed ?? data.frameNumber ?? 0);
      const frameMs =
        elapsedUs > 1000 ? elapsedUs / 1000 : Number(data.elapsed ?? session.lastFrameMs);
      // Flutter sends elapsed in microseconds typically
      const normalized =
        Number(data.elapsed) > 200 ? Number(data.elapsed) / 1000 : Number(data.elapsed) || frameMs;
      session.lastFrameMs = normalized;
      session.jankWindow.push(normalized > FRAME_BUDGET_MS ? 1 : 0);
      if (session.jankWindow.length > 30) session.jankWindow.shift();
    }
  }

  if (kind === "Timeline" || kind === "TimelineEvents") {
    const events = (event.timelineEvents ?? event.events ?? []) as Array<
      Record<string, unknown>
    >;
    for (const te of events) {
      const name = String(te.name ?? "");
      if (/Frame|Build|Raster/i.test(name) && typeof te.dur === "number") {
        const ms = te.dur / 1000;
        if (ms > 0 && ms < 500) {
          session.lastFrameMs = ms;
          session.jankWindow.push(ms > FRAME_BUDGET_MS ? 1 : 0);
          if (session.jankWindow.length > 30) session.jankWindow.shift();
        }
      }
    }
  }
}

async function pollLiveMetrics(session: Session) {
  if (session.mode !== "live" || !session.isolateId) return;
  const mem = await pollMemory(session);
  const jankRatio =
    session.jankWindow.length === 0
      ? session.lastFrameMs > FRAME_BUDGET_MS
        ? 1
        : 0
      : session.jankWindow.reduce((a, b) => a + b, 0) / session.jankWindow.length;

  // Approximate CPU pressure from recent frame cost vs 16.67ms budget
  const cpu = Math.min(
    100,
    Math.max(1, (session.lastFrameMs / FRAME_BUDGET_MS) * 55 + jankRatio * 25),
  );

  send(session.client, {
    type: "metrics",
    point: {
      t: Date.now(),
      cpu: Number(cpu.toFixed(1)),
      frameMs: Number((session.lastFrameMs || 0).toFixed(2)),
      jank: session.lastFrameMs > FRAME_BUDGET_MS ? 1 : 0,
      heapMb: Number(mem.heapMb.toFixed(2)),
      externalMb: Number(mem.externalMb.toFixed(2)),
    },
  });

  await pollHttpProfile(session);
}

async function connectVm(session: Session, url: string) {
  if (!isValidVmUrl(url)) {
    send(session.client, {
      type: "status",
      status: "error",
      message: "Enter a valid ws:// or wss:// VM Service URL (e.g. ws://127.0.0.1:8181/ws)",
    });
    return;
  }

  disconnectVm(session);
  session.mode = "idle";
  send(session.client, {
    type: "status",
    status: "connecting",
    mode: "live",
    message: `Connecting to ${url}`,
  });

  const vm = new WebSocket(url);
  session.vm = vm;

  vm.on("open", async () => {
    try {
      const isolateName = await resolveIsolate(session);
      await listenStreams(session);
      await refreshExtensions(session);
      session.mode = "live";
      session.lastFrameMs = 12;
      send(session.client, {
        type: "status",
        status: "connected",
        mode: "live",
        message: `Connected to VM Service`,
        isolateName,
      });
      session.pollTimer = setInterval(() => {
        void pollLiveMetrics(session);
      }, 500);
      // Refresh extension list periodically
      setTimeout(() => void refreshExtensions(session), 2000);
    } catch (err) {
      const message = err instanceof Error ? err.message : "Failed to initialize VM session";
      disconnectVm(session);
      send(session.client, { type: "status", status: "error", message });
    }
  });

  vm.on("message", (raw) => {
    try {
      const msg = JSON.parse(String(raw)) as {
        id?: string;
        error?: { message?: string };
        result?: unknown;
        method?: string;
        params?: { event?: Record<string, unknown> };
      };
      if (msg.id && session.pending.has(String(msg.id))) {
        const pending = session.pending.get(String(msg.id))!;
        session.pending.delete(String(msg.id));
        if (msg.error) {
          pending.reject(new Error(msg.error.message ?? "VM RPC error"));
        } else {
          pending.resolve(msg);
        }
        return;
      }
      if (msg.method === "streamNotify" && msg.params?.event) {
        handleVmEvent(session, msg.params.event);
      }
    } catch {
      /* ignore malformed */
    }
  });

  vm.on("error", (err) => {
    send(session.client, {
      type: "status",
      status: "error",
      message: `VM Service error: ${err.message}`,
    });
  });

  vm.on("close", () => {
    if (session.vm === vm) {
      clearTimers(session);
      session.vm = undefined;
      session.mode = "idle";
      send(session.client, {
        type: "status",
        status: "disconnected",
        message: "VM Service closed the connection",
      });
    }
  });
}

async function runStress(session: Session, action: string, params?: Record<string, unknown>) {
  if (session.mode === "mock") {
    // Simulate a load spike in mock metrics
    let bursts = 0;
    const spike = setInterval(() => {
      bursts += 1;
      const t = Date.now();
      send(session.client, {
        type: "metrics",
        point: {
          t,
          cpu: 70 + Math.random() * 25,
          frameMs: 28 + Math.random() * 40,
          jank: 1,
          heapMb: 55 + bursts * 1.5 + Math.random() * 3,
          externalMb: 12 + Math.random() * 2,
        },
      });
      if (action.includes("invoice") || action === "injectInvoices") {
        send(session.client, {
          type: "network",
          available: true,
          request: {
            id: randomUUID(),
            t,
            method: "POST",
            uri: "/api/invoices/bulk",
            latencyMs: Number((180 + Math.random() * 220).toFixed(1)),
            requestBytes: 12000 + bursts * 800,
            responseBytes: 2400,
            status: 201,
          },
        });
      }
      if (bursts >= 8) clearInterval(spike);
    }, 200);
    send(session.client, {
      type: "status",
      status: "connected",
      mode: "mock",
      message: `Mock stress "${action}" fired`,
    });
    return;
  }

  if (session.mode !== "live" || !session.isolateId) {
    send(session.client, {
      type: "error",
      message: "Connect to a Flutter VM Service (or start demo mode) before running stress tests",
    });
    return;
  }

  const methodMap: Record<string, string> = {
    injectInvoices: "ext.pulseflow.injectInvoices",
    spikeCpu: "ext.pulseflow.spikeCpu",
    allocateMemory: "ext.pulseflow.allocateMemory",
  };
  const method = methodMap[action] ?? action;
  if (!session.extensionMethods.includes(method)) {
    send(session.client, {
      type: "extension",
      info: {
        available: false,
        methods: session.extensionMethods.filter((m) => m.startsWith("ext.pulseflow.")),
        message: `Extension ${method} unavailable — add the PulseFlow stub to your Flutter app`,
      },
    });
    send(session.client, {
      type: "error",
      message: `Stress action unavailable: ${method} is not registered on the isolate`,
    });
    return;
  }

  try {
    await rpc(session, method, {
      isolateId: session.isolateId,
      ...(params ?? { count: 100 }),
    });
    send(session.client, {
      type: "status",
      status: "connected",
      mode: "live",
      message: `Stress RPC ${method} completed`,
    });
  } catch (err) {
    send(session.client, {
      type: "error",
      message: err instanceof Error ? err.message : "Stress RPC failed",
    });
  }
}

function attachClient(client: WebSocket) {
  const session: Session = {
    client,
    mode: "idle",
    pending: new Map(),
    seq: 0,
    lastFrameMs: 0,
    jankWindow: [],
    extensionMethods: [],
    httpProfileSupported: null,
  };

  send(client, {
    type: "status",
    status: "idle",
    message: "Bridge ready — connect a VM Service URL or start demo mode",
  });

  client.on("message", (raw) => {
    void (async () => {
      try {
        const msg = JSON.parse(String(raw)) as ClientMsg;
        switch (msg.type) {
          case "connect":
            await connectVm(session, msg.url);
            break;
          case "disconnect":
            disconnectVm(session, "Disconnected by user");
            send(client, { type: "status", status: "idle", message: "Disconnected" });
            break;
          case "mock":
            startMock(session);
            break;
          case "stress":
            await runStress(session, msg.action, msg.params);
            break;
          case "refreshExtensions":
            if (session.mode === "mock") {
              send(client, {
                type: "extension",
                info: {
                  available: true,
                  methods: ["ext.pulseflow.injectInvoices", "ext.pulseflow.spikeCpu"],
                  message: "Mock stress actions simulate load locally",
                },
              });
            } else if (session.mode === "live") {
              await refreshExtensions(session);
            } else {
              send(client, {
                type: "extension",
                info: {
                  available: false,
                  methods: [],
                  message: "Connect first to detect PulseFlow extensions",
                },
              });
            }
            break;
          default:
            send(client, { type: "error", message: "Unknown bridge command" });
        }
      } catch (err) {
        send(client, {
          type: "error",
          message: err instanceof Error ? err.message : "Invalid bridge message",
        });
      }
    })();
  });

  client.on("close", () => {
    disconnectVm(session);
  });
}

const server = createServer((_req, res) => {
  res.writeHead(200, { "Content-Type": "application/json" });
  res.end(JSON.stringify({ service: "pulseflow-bridge", port: BRIDGE_PORT, ok: true }));
});

const wss = new WebSocketServer({ server, path: "/bridge" });
wss.on("connection", (socket) => attachClient(socket));

server.listen(BRIDGE_PORT, "0.0.0.0", () => {
  console.log(`PulseFlow bridge listening on http://0.0.0.0:${BRIDGE_PORT} (ws path /bridge)`);
});
