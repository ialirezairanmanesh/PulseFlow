# PulseFlow

A highly visual, simplified Flutter performance dashboard. Connect to a running Flutter app through the Dart VM Service WebSocket and watch CPU/jank, memory, GC, and network signals in real time — without the full DevTools surface area.

## Stack

- Next.js (App Router) + TypeScript + Tailwind + shadcn-style UI primitives
- Recharts for live graphs
- Node WebSocket bridge (`server/bridge.ts`) that proxies the browser to the Dart VM Service

Browsers often cannot open arbitrary `ws://` targets (mixed content / localhost quirks). The bridge is required: the UI talks to PulseFlow on port **3847**, and the bridge opens the VM Service socket for you.

## Run the dashboard

```bash
npm install
npm run dev
```

- Web UI: [http://127.0.0.1:3846](http://127.0.0.1:3846)
- Bridge health: [http://127.0.0.1:3847](http://127.0.0.1:3847) (`ws://127.0.0.1:3847/bridge`)

Optional env:

```bash
PULSEFLOW_BRIDGE_PORT=3847
NEXT_PUBLIC_BRIDGE_PORT=3847
NEXT_PUBLIC_BRIDGE_HOST=127.0.0.1
```

## Point at a Flutter app

1. Run your Flutter app in debug/profile mode, e.g. `flutter run`.
2. Copy the Observatory / VM Service URL from the console (often `http://127.0.0.1:xxxxx/...`).
3. Convert it to a WebSocket URL: `ws://127.0.0.1:xxxxx/ws`.
4. Paste that into PulseFlow and click **Connect**.

If no Flutter app is available, use **Try demo mode** — metrics are clearly labeled as demo/mock.

## Stress-test extension

PulseFlow looks for service extensions named `ext.pulseflow.*`. If they are missing, the Stress Test Controller explains that and stays disabled (except demo mode).

Paste [`examples/pulseflow_extension.dart`](examples/pulseflow_extension.dart) into your Flutter project and register it from `main()`:

```dart
void main() {
  registerPulseFlowExtensions();
  runApp(const MyApp());
}
```

Hot-restart the app, reconnect PulseFlow, then use **Inject 100 invoices** (or CPU/memory spikes) to drive visible graph spikes.

## What the bridge reads

| Signal | Source | Notes |
| --- | --- | --- |
| Frame / jank | `Extension` / `Timeline` (`Flutter.Frame`) | Jank flagged when frame time &gt; ~16.67ms |
| CPU pressure | Derived from recent frame cost | Not a full CPU profiler — a lightweight pressure estimate |
| Memory | `getMemoryUsage` / `getAllocationProfile` | Depends on VM Service version |
| GC | `GC` stream | Shown as event markers in Recent signals |
| Network | `getHttpProfile` (DDS) | Degrades gracefully when unavailable |

## Scripts

| Command | Purpose |
| --- | --- |
| `npm run dev` | Bridge + Next.js on ports 3847 / 3846 |
| `npm run bridge` | Bridge only |
| `npm run build` / `npm start` | Production build + serve |
| `npm run lint` | ESLint |
